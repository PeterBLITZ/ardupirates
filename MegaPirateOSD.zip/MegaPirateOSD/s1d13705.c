#define target_avr       // define for codevision; empty for builder
  #include <math.h>
#ifdef target_avr
 #define type_flash flash
 #define IBB // inverted endian in S1D13705 �����!!!!
 #define bool bit
 #define true 1
 #define false 0
// #define byte unsigned char
#else
#define type_flash const
#endif




#define CLK PORTC.0
#define ASL PORTC.1
#define ASH PORTC.2
#define WE PORTC.3
#define RD PORTC.4
#define CS PORTC.5
#define WAIT PINC.6
#define A16 PORTD.7
#define nop #asm("nop");

#define font_height 8
#define font_width 6
#define scr_height 64
#define scr_width 64
#define font_set oem6x8
//#include "X_convert_i.c" // inverted bitfields
//#include "X_convert.c" // normal font

byte char_x=0,char_y=0;

#include "oem866_6x8.c"











byte l_mask_array[8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

void lcd_setpixel( short x,  short y, char pcolor) // pixel color: 1-set, 0-clear, 2-toggle
{unsigned short byte_off;
char bit_off,tmpc;
byte_off=(x>>3)+y*(scr_width>>3);
bit_off=x & 7;
tmpc=ahi_buffer[byte_off];
if (pcolor==1) tmpc |= (l_mask_array[bit_off]);
if (pcolor==0) tmpc &= (l_mask_array[bit_off]) ^ 255 ;
if (pcolor==2) tmpc ^= (l_mask_array[bit_off]);
ahi_buffer[byte_off]=tmpc;
return;}


void lcd_line(  short x1,  short y1,  short x2,  short y2,   short mode )
{
   int deltaX = abs(x2 - x1);
    int deltaY = abs(y2 - y1);
    int signX = x1 < x2 ? 1 : -1;
    int signY = y1 < y2 ? 1 : -1;
    int error = deltaX - deltaY;
    int error2;
if ((x1>=scr_width)||(x1<0)||(y1>=scr_height)||(y1<0)) return;
//if ((y1>=scr_height)||(y1<0)) return;
if ((x2>=scr_width)||(x2<0)||(y2>=scr_height)||(y2<0)) return;
//if ((y2>=scr_height)||(y2<0)) return;

    for (;;)
    {
        lcd_setpixel(x1, y1,mode);

        if(x1 == x2 && y1 == y2)
            break;

        error2 = error * 2;

        if(error2 > -deltaY)
        {
            error -= deltaY;
            x1 += signX;
        }

        if(error2 < deltaX)
        {
            error += deltaX;
            y1 += signY;
        }
    }
}

void lcd_circle(short xCenter, short yCenter, short radius, short mode)
 {  short tSwitch, y, x = 0;
    short d;
   d = yCenter - xCenter;
   y = radius;
   tSwitch = 3 - 2 * radius;
   while (x <= y)
    { lcd_setpixel(xCenter + x, yCenter + y, mode);
      lcd_setpixel(xCenter + x, yCenter - y, mode);
     lcd_setpixel(xCenter - x, yCenter + y, mode);
      lcd_setpixel(xCenter - x, yCenter - y, mode);
      lcd_setpixel(yCenter + y - d, yCenter + x, mode);
      lcd_setpixel(yCenter + y - d, yCenter - x, mode);
      lcd_setpixel(yCenter - y - d, yCenter + x, mode);
      lcd_setpixel(yCenter - y - d, yCenter - x, mode);
      if (tSwitch < 0)  tSwitch += (4 * x + 6);  else  { tSwitch += (4 * (x - y) + 10); y--; }
      x++;
    }
 }


void intos(int x,long num,byte dig,byte zeros,byte zpt) // pmode 5: into buffer
{
byte leadz=0;
unsigned short div;
unsigned long rem;
    
if (num<0){num=-num;line_buffer[x++]='-';}
else line_buffer[x++]=' ';



rem=num;
if (dig>=7)
{
div=rem/1000000;
if (div) leadz=1;
rem-=1000000*div;
if (div | zeros| leadz|(zpt==6)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==6) line_buffer[x++]='.';
if (dig>=6)
{
div=rem/100000;
if (div) leadz=1;
rem-=100000*div;
if (div | zeros| leadz|(zpt==5)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==5) line_buffer[x++]='.';
if (dig>=5)
{
div=rem/10000;
if (div) leadz=1;
rem-=10000*div;
if (div | zeros | leadz|(zpt==4)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==4) line_buffer[x++]='.';
if (dig>=4)
{
div=rem/1000;
if (div) leadz=1;
rem-=1000*div;
if (div | zeros| leadz|(zpt==3)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==3) line_buffer[x++]='.';
if (dig>=3)
{
div=rem/100;
if (div) leadz=1;
rem-=100*div;
if (div | zeros| leadz|(zpt==2)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==2) line_buffer[x++]='.';
if (dig>=2)
{
div=rem/10;
if (div) leadz=1;
rem-=10*div;
if (div | zeros| leadz|(zpt==1)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==1) line_buffer[x++]='.';

line_buffer[x++]=((byte)rem+0x30);
}


