#define target_avr       // define for codevision; empty for builder
  #include <math.h>
#ifdef target_avr
 #define type_flash flash
 #define IBB // inverted endian in S1D13705 �����!!!!
 #define bool bit
 #define true 1
 #define false 0
// #define byte unsigned char
#else
#define type_flash const
#endif




#define CLK PORTC.0
#define ASL PORTC.1
#define ASH PORTC.2
#define WE PORTC.3
#define RD PORTC.4
#define CS PORTC.5
#define WAIT PINC.6
#define A16 PORTD.7
#define nop #asm("nop");

#define font_height 8
#define font_width 6
#define scr_height 64
#define scr_width 64
#define font_set oem6x8
//#include "X_convert_i.c" // inverted bitfields
//#include "X_convert.c" // normal font

byte char_x=0,char_y=0;
/*
flash  unsigned char b2i[256]={                 // endian swapped bits lookup
0,128,64,192,32,160,96,224,16,144,80,208,48,176,112,240,8,136,
72,200,40,168,104,232,24,152,88,216,56,184,120,248,4,132,68,
196,36,164,100,228,20,148,84,212,52,180,116,244,12,140,76,204,
44,172,108,236,28,156,92,220,60,188,124,252,2,130,66,194,34,
162,98,226,18,146,82,210,50,178,114,242,10,138,74,202,42,170,
106,234,26,154,90,218,58,186,122,250,6,134,70,198,38,166,102,
230,22,150,86,214,54,182,118,246,14,142,78,206,46,174,110,238,
30,158,94,222,62,190,126,254,1,129,65,193,33,161,97,225,17,145,
81,209,49,177,113,241,9,137,73,201,41,169,105,233,25,153,89,217,
57,185,121,249,5,133,69,197,37,165,101,229,21,149,85,213,53,
181,117,245,13,141,77,205,45,173,109,237,29,157,93,221,61,189,
125,253,3,131,67,195,35,163,99,227,19,147,83,211,51,179,115,
243,11,139,75,203,43,171,107,235,27,155,91,219,59,187,123,251,7,
135,71,199,39,167,103,231,23,151,87,215,55,183,119,247,15,143,
79,207,47,175,111,239,31,159,95,223,63,191,127,255};
*/

#include "oem866_6x8.c"

void lcd_msg1(type_flash char *text);
void beeper(byte beeep);










byte l_mask_array[8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

void lcd_setpixel( short x,  short y, char pcolor) // pixel color: 1-set, 0-clear, 2-toggle
{unsigned short byte_off;
char bit_off,tmpc;
if (x>=scr_width) return;
if (x<0) return;
if (y>=scr_height) return;
if (y<0) return;
byte_off=(x>>3)+y*(scr_width>>3);
bit_off=x & 7;
tmpc=ahi_buffer[byte_off];
if (pcolor==1) tmpc |= (l_mask_array[bit_off]);
if (pcolor==0) tmpc &= (l_mask_array[bit_off]) ^ 255 ;
if (pcolor==2) tmpc ^= (l_mask_array[bit_off]);
ahi_buffer[byte_off]=tmpc;
return;}

/*
flash unsigned char a2o[256] = {
0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
0xFF, 0xF6, 0xF7, 0x20, 0xFD, 0xF2, 0x7C, 0x20, 0xF0, 0x20, 0xF4, 0x20, 0x20, 0x20, 0x20, 0xF8,
0xF8, 0xB1, 0xF6, 0xF7, 0xF3, 0x20, 0x20, 0xFA, 0xF1, 0xFC, 0xF5, 0x20, 0x20, 0x20, 0x20, 0xF9,
0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x8D, 0x8E, 0x8F,
0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xDB, 0x9C, 0x9D, 0x9E, 0x9F,
0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF
};
*/
/*static unsigned char o2a[256] = {
0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF,
0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF,
0x2D, 0x2D, 0x2D, 0x7C, 0x2B, 0x7C, 0x7C, 0x2D, 0x2D, 0x7C, 0x7C, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D,
0x2D, 0x2B, 0x2D, 0x2B, 0x2D, 0x2B, 0x7C, 0x7C, 0x2D, 0x2D, 0x7C, 0x2D, 0x7C, 0x3D, 0x2B, 0x7C,
0x7C, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 0x2B, 0x2B, 0x2D, 0x2D, 0x2D, 0x2D, 0x7C, 0x7C, 0x2D,
0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF,
0xA8, 0xB8, 0xA5, 0xB4, 0xAA, 0xBA, 0xB2, 0xB3, 0xAF, 0xBF, 0xB7, 0xFB, 0xB9, 0xA4, 0xFE, 0xA0
};
  */


/*
void lcd_oemchar (byte glyph1) // put a char to the position. Color 0-normal, 1-inverted, 2-XOR
{unsigned short byte_off;
long bit_off;
byte bit_rem;
unsigned char tmpc,tmpz,icnt;
byte glyph;
unsigned short pchr;
glyph=a2o[glyph1];

bit_off=char_x+char_y*scr_width;
bit_rem=bit_off&7; // 00000001
if (bit_rem==0)
{
        byte_off=bit_off>>3;
        pchr=(short)glyph*font_height;
                for (icnt=0;icnt<font_height;icnt++)
                        {tmpc=b2i[font_set[pchr]]; pchr++;
                        tmpc |= ahi_buffer[byte_off];
                        ahi_buffer[byte_off]=tmpc;
                        byte_off+=scr_width>>3; // columns
                        }



}
else // 2 bytes split in halves
{
        byte_off=bit_off>>3;
        pchr=(short)glyph*font_height;
                for (icnt=0;icnt<font_height;icnt++)
                        {tmpc=b2i[font_set[pchr]]; pchr++;
                        tmpz=tmpc<<bit_rem;
                        tmpz |= ahi_buffer[byte_off];
                        ahi_buffer[byte_off]=tmpz;
                        tmpz=tmpc>>(8-bit_rem);
                        tmpz |= ahi_buffer[byte_off+1];
                        ahi_buffer[byte_off+1]=tmpz;

                        byte_off+=scr_width>>3; // columns
                        }





}
char_x+=font_width;
return;}
*/


 /*
void lcd_print(type_flash char *text) // curcol,currow,mode 0-normal,1-inverted,2-XOR
{char disp=0;
char tmpc;
while(*(text+disp)!=0)
{tmpc=*(text+disp);

lcd_oemchar(tmpc); // inc posn
disp++;
}
return;}
   */

void lcd_line(  short x1,  short y1,  short x2,  short y2,   short mode )
{
    int deltaX = abs(x2 - x1);
    int deltaY = abs(y2 - y1);
    int signX = x1 < x2 ? 1 : -1;
    int signY = y1 < y2 ? 1 : -1;
    int error = deltaX - deltaY;
    int error2;

    for (;;)
    {
        lcd_setpixel(x1, y1,mode);

        if(x1 == x2 && y1 == y2)
            break;

        error2 = error * 2;

        if(error2 > -deltaY)
        {
            error -= deltaY;
            x1 += signX;
        }

        if(error2 < deltaX)
        {
            error += deltaX;
            y1 += signY;
        }
    }
}

void lcd_circle(short xCenter, short yCenter, short radius, short mode)
 {  short tSwitch, y, x = 0;
    short d;
   d = yCenter - xCenter;
   y = radius;
   tSwitch = 3 - 2 * radius;
   while (x <= y)
    { lcd_setpixel(xCenter + x, yCenter + y, mode);
      lcd_setpixel(xCenter + x, yCenter - y, mode);
     lcd_setpixel(xCenter - x, yCenter + y, mode);
      lcd_setpixel(xCenter - x, yCenter - y, mode);
      lcd_setpixel(yCenter + y - d, yCenter + x, mode);
      lcd_setpixel(yCenter + y - d, yCenter - x, mode);
      lcd_setpixel(yCenter - y - d, yCenter + x, mode);
      lcd_setpixel(yCenter - y - d, yCenter - x, mode);
      if (tSwitch < 0)  tSwitch += (4 * x + 6);  else  { tSwitch += (4 * (x - y) + 10); y--; }
      x++;
    }
 }

 // tbitmap



// #include "pix.c"
/*void lcd_bmp(type_flash char *pix, char y, char x, char pmode) // mode 0-norm,1-inv,2-xor
// picture format: width,height,[bitmap]
{unsigned short tmc,x2,y2,baseoff;
char tmw,tmh,tmpc;
baseoff=x+(short)y*40*font_height; // base offset for x and y
tmw=(*pix)>>3; //width in bytes
tmh=*(pix+1) ;//height
tmc=2;
for (y2=0;y2<tmh;y2++)
{for (x2=0;x2<tmw;x2++)
     {
tmpc= *(pix+tmc);
if (pmode==2) tmpc ^= lcd_getb(0,baseoff);
if (pmode==1) tmpc ^=255;
lcd_putb(0,baseoff, tmpc);
baseoff++;
tmc++;
     }
baseoff+=40-tmw;
 }
return;} */
/*
void lcd_drawbox(unsigned short x,unsigned short y,unsigned short dispx,unsigned short dispy,char pmode)
{
lcd_line(x,y,x,y+dispy,pmode);
lcd_line(x,y,x+dispx,y,pmode);
lcd_line(x+dispx,y+dispy,x,y+dispy,pmode);
lcd_line(x+dispx,y+dispy,x+dispx,y,pmode);
return;}


void lcd_fillbox(unsigned short x,unsigned short y,unsigned short dispx,unsigned short dispy,char pmode)
{
unsigned short i,j;
i=y;j=y+dispy;
while (i<j)
{lcd_line(x,i,x+dispx,i,pmode);
i++;}
return;

}
*/
void intos(int x,long num,byte dig,byte zeros,byte zpt) // pmode 5: into buffer
{
byte cpush,leadz=0;
unsigned short div;
unsigned long rem;
    
if (num<0){num=-num;line_buffer[x++]='-';}
else line_buffer[x++]=' ';



rem=num;
if (dig>=7)
{
div=rem/1000000;
if (div) leadz=1;
rem-=1000000*div;
if (div | zeros| leadz|(zpt==6)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==6) line_buffer[x++]='.';
if (dig>=6)
{
div=rem/100000;
if (div) leadz=1;
rem-=100000*div;
if (div | zeros| leadz|(zpt==5)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==5) line_buffer[x++]='.';
if (dig>=5)
{
div=rem/10000;
if (div) leadz=1;
rem-=10000*div;
if (div | zeros | leadz|(zpt==4)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==4) line_buffer[x++]='.';
if (dig>=4)
{
div=rem/1000;
if (div) leadz=1;
rem-=1000*div;
if (div | zeros| leadz|(zpt==3)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==3) line_buffer[x++]='.';
if (dig>=3)
{
div=rem/100;
if (div) leadz=1;
rem-=100*div;
if (div | zeros| leadz|(zpt==2)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==2) line_buffer[x++]='.';
if (dig>=2)
{
div=rem/10;
if (div) leadz=1;
rem-=10*div;
if (div | zeros| leadz|(zpt==1)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==1) line_buffer[x++]='.';

line_buffer[x++]=((byte)rem+0x30);
}



/*
void lcd_arc(void) // �������� :)
{
signed int bx[30]={20,20,70,140,100,164,20,34,85,100,164,20,20,100,164,20,34,85,130,20,70,140,20,34,85,130,130,20,70,140};
signed int by[30]={100,164,50,100,164,20,100,164,20,34,185,30,120,70,40,50,120,70,40,20,34,185,30,34,185,30,120,70,40,50};
signed int br[30]={3,7,4,3,7,4,3,8,6,8,6,9,3,8,3,7,4,3,8,6,5,3,8,3,9,5,9,5,3,8};
signed int dbx[30]={1,-1,2,-1,2,1,-1,3,-1,1,3,-1,2,3,-1,3,1,-2,1,-2,-1,-2,-1,-2,1,1,2,-2,-1,-3};
signed int dby[30]={-5,-4,-2,-4,-2,-3,-3,-2,-3,-2,-3,-4,-2,-2,-2,-3,-3,-2,-2,-2,-4,-3,-2,-2,-3,-4,-4,-2,-2,-2};
byte ccnt;
int bxt,byt;

long k;
lcd_cls();

ccnt=25;while (ccnt){lcd_circle(bx[ccnt],by[ccnt],br[ccnt],1);ccnt--;}
arc_lp01:
ccnt=25;while (ccnt){
lcd_circle(bx[ccnt],by[ccnt],br[ccnt],0);
bxt=bx[ccnt]+dbx[ccnt];
byt=by[ccnt]+dby[ccnt];
if ((bxt>320)|(bxt<0)) dbx[ccnt]=-dbx[ccnt];
if ((byt>240)|(byt<0)) by[ccnt]=240;//dby[ccnt]=-dby[ccnt];
bx[ccnt]+=dbx[ccnt];
by[ccnt]+=dby[ccnt];
lcd_circle(bx[ccnt],by[ccnt],br[ccnt],1);
ccnt--;}
curcol=5;
currow=10;
lcd_print("���� ������. ������� ����� ������",0);
curcol=13;
currow=11;
keyscan();
if (keybuf<6) return;//lcd_print("�����",0);
k=10;
while (k)
{k--;}

goto arc_lp01;
}

 */
//void lcd_dispframe




