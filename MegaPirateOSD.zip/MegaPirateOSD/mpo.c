
#include <mega88.h> 
#define byte unsigned char
#define ulong unsigned long
//volatile char tempspdr;
//#define Wait() while(!(SPSR&128)); tempspdr=SPDR



// Static functions and variables

register char tmpch @3;
register unsigned int line @4;




//===internal subroutines header
        void config(void);
        void draw_line(void);
// end header


//#pragma savereg-
register char i;
byte flag=0;
// Syncro pulse routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
	TCNT0=0; // reset timer
	TCNT2=61; // reset 80us interrupt
	while(TCNT0<180);//92); // wait 5us to see if H or V sync

	if(!(PIND.2)) { // its an H sync
		TCNT0=0; // reset timer
		line++;
		draw_line();
	}
	else { // tis a V sync
		if(line>200)line=0;
	}

}

char line_buffer[120];
char status_buffer[6];
char ahi_buffer[512];
#include "X_convert.c"
//#include "oem866_6x8.c"
#include "s1d13705.c"


// Timer 2 overflow interrupt service routine // each 80 us, 2MHz tick
interrupt [TIM2_OVF] void timer2_ovf_isr(void)
{
// Place your code here
	TCNT2=177; // reset 80us interrupt
	//if (UCSR0A & (1<<RXC0)) MsgHandler(UDR0); //poll the serial port

}

// Declare your global variables here
int xx;
byte ptmo=0;
//==================================================

void lcd_cls(void)
{for (xx=0;xx<sizeof(ahi_buffer);xx++)
ahi_buffer[xx]=0x0;
for (xx=0;xx<sizeof(line_buffer);xx++)
line_buffer[xx]=0x0;
for (xx=0;xx<sizeof(status_buffer);xx++)
status_buffer[xx]=0x0;
}                 
 //==================================================

void print(int pos,flash char *text)
{
int disp=0;
while(*(text+disp)!=0)
{line_buffer[pos+disp]=*(text+disp);
disp++;}
}
//==================================================

void draw_homebird(byte hdg)
{
char j; // position from 0 to 63
j=hdg;

       // j=hdg;
 // central pixel
 lcd_setpixel(j,3,1);
 lcd_line(j+1,4,j-1,4,1);
 lcd_line(j+2,5,j-2,5,1);
}
//==================================================

void draw_pitchbird(int hdg)
{
byte j; // position from 0 to 63
// pitch from -31 to +31
if (hdg< -31) hdg=-31;
if (hdg> 31) hdg=31;
 j=32+hdg;

 // central pixel
 lcd_setpixel(60,j,1);
 lcd_line(59,j+1,59,j-1,1);
 lcd_line(58,j+2,58,j-2,1);
}
//==================================================    
int v_bat=0;
void draw_ahiline(int roll)
{float sinr,cosr;
// line length 20
sinr=sin(roll*0.03488);
cosr=cos(roll*0.03488);
lcd_line(32-20*cosr,32+20*sinr,32+20*cosr,32-20*sinr,1);
lcd_line(32,32,32-8*sinr,32-8*cosr,1);
}

#define ADC_VREF_TYPE 0x40

void display_vbat(void)
{ int jj;
ADMUX=1 | (ADC_VREF_TYPE & 0xff);
// Start the AD conversion
ADCSRA|=0x40;
// Wait for the AD conversion to complete
while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;

jj=ADCW;
jj=jj*3;
v_bat=jj;
intos(0,jj,4,0,2); // print battery voltage (5 digs)
print(5,"V");





}

// process rx commands

//==================================================


byte syncro=0xcb,pkt_ctr=0,pkt_type=0;
byte pak_buf0[11],pak_buf1[11],pak_buf2[11];
byte tmpr;
byte osdoff=0;
void receive_rx(void)
{
/*buffer format:
0-sync word changed (0xcb, 0x34)
1  packet type (0 - ahi,bat,cur,mah, 1 - nav, 2 - maintenance
2       0               1               2
3       roll            gpslat1         gpsSPD
4       pitch           gpslat2         gpsALTH
5       homeset         gpslat3         gpaALTL
6       homeL           gpslat4         gpsDISH
7       control_mode    gpslon1         gpsDISL
8       BATl            gpslon2         status
9       Ih              gpslon3         config (1 - OSD off)
10      IL (up 80.0A)   gpslon4         emerg


==
status:
0..3
        0-Manual
*/

// this routine is called when received 1 byte
// 11 bytes length

tmpr=UDR0;
        switch (pkt_type)
        {case 0: pak_buf0[pkt_ctr]=tmpr;break;
         case 1: pak_buf1[pkt_ctr]=tmpr;break;
         case 2: pak_buf2[pkt_ctr]=tmpr;break;
        }
if (pkt_ctr==0) //first byte received
        {if (tmpr==syncro) {pkt_ctr++;syncro^=255;ptmo=20;}}
                //else dont increase
else pkt_ctr++; // non-first byte received
if(pkt_ctr==2) pkt_type=tmpr;
if (pkt_ctr>=11) pkt_ctr=0; // end of packet

}

//==================================================
// graphic variables
signed char v_pitch=0,v_roll=0;
signed int v_home=0;
//==================================================

void process0(void) // process the packet0
{
/*
0-sync word changed (0xcb, 0x34)
1  packet type (0 - ahi,bat,cur,mah, 1 - nav, 2 - maintenance
2       0    
3       roll 
4       pitch
5       homeH
6       homeL
7       control_mode
8       0
9       Ih
10      IL (up 80.0A)
*/
v_roll=pak_buf0[3];
v_pitch=pak_buf0[4];
v_home=pak_buf0[6];
switch(pak_buf0[7])
        {case 0: print(30,"MANUAL");break;
         case 1: print(30,"CIRCLE");break;
        case 2: print(30,"STABLE");break;
        case 5: print(30,"WIRE A");break;
        case 6: print(30,"WIRE B");break;
        case 10: print(30,"AUTOPILOT");break;
        case 11: print(30,"RTL");break;
        case 12: print(30,"LOITER");break;
        case 13: print(30,"TAKEOFF");break;
        case 14: print(30,"LANDING");break;
        default: print(30,"UNKNOWN");break;
        
        }

/*
#define MANUAL 0
#define CIRCLE 1
#define STABILIZE 2

#define FLY_BY_WIRE_A 5
#define FLY_BY_WIRE_B 6
			
#define AUTO 10
#define RTL 11
#define LOITER 12
#define TAKEOFF 13
#define LAND 14
*/
intos(40,((int)pak_buf0[9]<<8)|pak_buf0[10],3,0,1); // print current (5 digs)
print(45,"A");
}
//==================================================
void process1(void) // type 1 packet (GPS coords)
{
ulong gps_lat=0,gps_lon=0;

gps_lat=(ulong)pak_buf1[6]+((ulong)pak_buf1[5]<<8)+((ulong)pak_buf1[4]<<16)+((ulong)pak_buf1[3]<<24);
gps_lon=(ulong)pak_buf1[10]+((ulong)pak_buf1[9]<<8)+((ulong)pak_buf1[8]<<16)+((ulong)pak_buf1[7]<<24);


intos(80,gps_lat,7,1,4); // print current (5 digs)
intos(108,gps_lon,7,1,4); // print current (5 digs)
}
//==================================================


void process2(void) // type 2 packet (dis,alt,spd), 10Hz update
{ 
static char icnt,jjj;
print(61,"SPD");
intos(64,(ulong)pak_buf2[3],3,0,0); // print speed (3 digs)
print(69,"ALT");
intos(72,((unsigned short)pak_buf2[4]<<8)+(unsigned short)pak_buf2[5],5,0,0); // print altitude (5 digs)
print(99,"DIS");
intos(102,((unsigned short)pak_buf2[6]<<8)+(unsigned short)pak_buf2[7],5,0,0); // print distance (5 digs)


if (pak_buf2[8]<4) print(92,"NOFIX");                        // sat count
else { line_buffer[92]=pak_buf2[8]+0x30;line_buffer[93]='S';}


icnt++;icnt&=15;
        if(icnt&8) // - flash!!!
        {if (!ptmo)
                {jjj=0;
                while(jjj<6) {status_buffer[jjj]='#';jjj++;}
                }
        else{        
        jjj=pak_buf2[10];  // status display
         status_buffer[0]=(v_bat<1040)?'B':' '; //battery
        status_buffer[1]=(jjj&2)?'R':' '; //radio
        status_buffer[2]=(jjj&4)?'F':' '; //flaps TAKEOFF
//        status_buffer[3]=(jjj&8)?'S':' '; //speed
        status_buffer[4]=(pak_buf2[8]<3)?'G':' ';//GPS
        ptmo--;
        }
       }
        if(jjj&8) status_buffer[2]='F'; //flaps LAND
        
        status_buffer[5]=(jjj&32)?'L':' ';//BANO
   //     if(icnt&8) // - flash!!!


//osdoff=pak_buf2[9]; // OSD off control: 0 - ON, 1-OFF
}
//==================================================




byte time_sec=0;
byte time_sec1=0;
byte time_min=0;
byte time_min1=0;
byte time_hr=0;

void count_time(void) // 50Hz
{static char cnt=0;
cnt++;
if (cnt<50) return;
cnt=0;
time_sec++; if (time_sec>9) {time_sec=0;time_sec1++;}
if (time_sec1>5) {time_sec1=0;time_min++;}
if (time_min>9) {time_min=0;time_min1++;}
if (time_min1>9) {time_min1=0;}
}


void main(void)
{ 
config();
SMCR=1;
lcd_cls();  
//print(0, "                                        ");
//print(40,"                                        ");


while(1)
{// loop

if (flag)     //50 Hz
{
  flag=0;
  lcd_cls();
  count_time();
// draw scales and crosshair
for(i=0;i<64;i+=4)
lcd_setpixel(i,0,1);
for(i=0;i<64;i+=16) // upper scale (home)
{lcd_setpixel(i,1,1);
lcd_setpixel(i,2,1);}

for(i=0;i<64;i+=4) // right scale (pitch)
lcd_setpixel(63,i,1);
for(i=0;i<64;i+=16) //
{lcd_setpixel(62,i,1);
lcd_setpixel(61,i,1);}

// home bird
draw_homebird(v_home);
draw_pitchbird(v_pitch);
lcd_circle(32,32,2,1);
draw_ahiline(v_roll);

process0();
process1();
process2();
display_vbat();


// print clocks at line2
line_buffer[51]=time_min1+0x30;
line_buffer[52]=time_min+0x30;
line_buffer[53]=':';
line_buffer[54]=time_sec1+0x30;
line_buffer[55]=time_sec+0x30;




 }

#asm   
sleep
#endasm
} // end main loop
}








	#define graf_dsp    135


//***************************Line drawing routine
// 2x40 line buffer
// 64x64 graphics buffer
void draw_line(void)
{
#asm("push r31 push r30");
if(line==30){	SPCR = (1<<6) | (1<<4) | (1<<2);}
	if ((line >= 40) && (line < (48))) // 1st line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<213); //wait ~7.5us from H-sync 
	        tmpch=line-40;// R3
	        DDRB.1=1;
		PORTB.1=0;         
        #asm   
.equ _oem68=_oem6x8        
clr r15 // zero register
ldi r18,40   // counter downto 0
ldi r27,high(_line_buffer)
ldi r26,low(_line_buffer) // XL
ldi r17,8
        // main cycle: spdr=oem6x8[8*line_buffer[cnt]+subline]
write_str:
ld r16,X+ mul r16,r17 // line_buffer[cnt]*8
clc ldi r31,high(2*_oem68) ldi r30,low(2*_oem68)  // ZL
add r30,r0 adc r31,r1 clc add r30,r3 adc r31,r15
lpm r16,Z out SPDR,r16 dec r18 brne write_str
//        wait_t:
//        in r16,SPSR sbrs r19,7 rjmp wait_t in r16,SPDR
#endasm
TCNT0=0;
while(TCNT0<20);
	        DDRB.1=0;
	}
	
	else if ((line >= 52) && (line < (60))) // 2nd line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<203); //wait ~7.5us from H-sync  // 10 pts each condition
	        tmpch=line-52;// R3
	        DDRB.1=1;
		PORTB.1=0;         
        #asm
clr r15 // zero register
ldi r18,40   // counter downto 0
ldi r27,high(_line_buffer+40)
ldi r26,low(_line_buffer+40) // XL
ldi r17,8
        // main cycle: spdr=oem6x8[8*line_buffer[cnt]+subline]
write_str1:
ld r16,X+ mul r16,r17 // line_buffer[cnt]*8
clc ldi r31,high(2*_oem68) ldi r30,low(2*_oem68)  // ZL
add r30,r0 adc r31,r1 clc add r30,r3 adc r31,r15
lpm r16,Z out SPDR,r16 dec r18 brne write_str1
//        wait_t:
//        in r16,SPSR sbrs r19,7 rjmp wait_t in r16,SPDR
#endasm
TCNT0=0;
while(TCNT0<20);
DDRB.1=0;
	} 
//##################### Graphics 64x64
	else if ((line >= graf_dsp) && (line < (graf_dsp+64))) // 2nd line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<218); //wait ~7.5us from H-sync  // 10 pts each condition
		TCNT0=0;
		while(TCNT0<214); //wait ~7.5us from H-sync  // 10 pts each condition
	        tmpch=line-graf_dsp;// R3
	        DDRB.1=1;
	        PORTB.1=0;
		//PORTB.1=1; 
        #asm
ldi r18,8   // counter downto 0
ldi r27,high(_ahi_buffer)
ldi r26,low(_ahi_buffer) // XL
ldi r17,8
mul r3,r17
add r26,r0
adc r27,r1
        // main cycle: spdr=ahi_buffer[8*r3+r18]
#define _PORTB 5
write_str2:
ld r16,X+  
rol r16
out _PORTB,r16
nop   
nop   
ror r16
out _PORTB,r16
nop   
nop   
ror r16
out _PORTB,r16
nop   
nop   
ror r16
out _PORTB,r16
nop   
nop   
ror r16
out _PORTB,r16
nop   
nop   
ror r16
out _PORTB,r16
nop   
nop   
ror r16
out _PORTB,r16
   
nop   
ror r16
dec r18
out _PORTB,r16
brne write_str2



#endasm
PORTB.1=0;
DDRB.1=0;
}

//###################### 3rd line from 80

	else if ((line >= 280) && (line < (288))) // 2nd line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<203); //wait ~7.5us from H-sync  // 10 pts each condition
	        tmpch=line-280;// R3
	        DDRB.1=1;
		PORTB.1=0;         
        #asm
clr r15 // zero register
ldi r18,40   // counter downto 0
ldi r27,high(_line_buffer+80)
ldi r26,low(_line_buffer+80) // XL
ldi r17,8
        // main cycle: spdr=oem6x8[8*line_buffer[cnt]+subline]
write_str3:
ld r16,X+ mul r16,r17 // line_buffer[cnt]*8
clc ldi r31,high(2*_oem68) ldi r30,low(2*_oem68)  // ZL
add r30,r0 adc r31,r1 clc add r30,r3 adc r31,r15
lpm r16,Z out SPDR,r16 dec r18 brne write_str3
//        wait_t:
//        in r16,SPSR sbrs r19,7 rjmp wait_t in r16,SPDR
#endasm
TCNT0=0;
while(TCNT0<20);
DDRB.1=0;
}
//###################### status line from status_buffer

	else if ((line >= 265) && (line < (273))) // 2nd line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<225); //wait ~7.5us from H-sync  // 10 pts each condition
		TCNT0=0;
		while(TCNT0<45); //wait ~7.5us from H-sync  // 10 pts each condition
		TCNT0=0;
		while(TCNT0<203); //wait ~7.5us from H-sync  // 10 pts each condition
	        tmpch=line-265;// R3
	        DDRB.1=1;
		PORTB.1=0;         
        #asm
clr r15 // zero register
ldi r18,6   // counter downto 0
ldi r27,high(_status_buffer)
ldi r26,low(_status_buffer) // XL
ldi r17,8
        // main cycle: spdr=oem6x8[8*line_buffer[cnt]+subline]
write_str4:
ld r16,X+ mul r16,r17 // line_buffer[cnt]*8
clc ldi r31,high(2*_oem68) ldi r30,low(2*_oem68)  // ZL
add r30,r0 adc r31,r1 clc add r30,r3 adc r31,r15
lpm r16,Z out SPDR,r16 dec r18 brne write_str4
//        wait_t:
//        in r16,SPSR sbrs r19,7 rjmp wait_t in r16,SPDR
#endasm
TCNT0=0;
while(TCNT0<20);
DDRB.1=0;

	}else if (line==graf_dsp+64) {flag=1;}


if(UCSR0A&128) receive_rx();


#asm("pop r30 pop r31");

//***************************end Line drawing routine
}














void config(void)
{
	// PORT B - Video Out
	//PB0 used for background dimming
	PORTB = 0x00;							// Initial state is everything off
	DDRB  = 0x3d;							// Data direction register for port B
        DDRB.1=1;
	// PORT D - Not really used
	//	Bit/Pin 2 (out) connected the control line on a servo
	PORTD = 0x00;							// Initial state is everything off
	DDRD  = 0x00;							// Data direction register for port D
	
	//enable the SPI port
	SPDR = 0; //CLEAR THE SPI DATA REGISTER!!! OR WILL HOSE THE VIDEO RANDOMLY IF NOT CLEARED!
	SPCR = (1<<6) | (1<<4) | (1<<2);
	SPSR = 1;

	// Set baud rate of USART to 9600 baud at 8 MHz
UCSR0A=0x00;
UCSR0B=0x10;
UCSR0C=0x06;
UBRR0H=0x00;
UBRR0L=0x9f;//0x33;

	// Setup idle mode sleeps

	//set_sleep_mode(SLEEP_MODE_IDLE);
	
	TCCR0B = 0x01; //enable timer w/ no prescaling
	
	TCCR2B = 0x02; //enable timer with /8 prescale
	TCNT2 = 84; //overflow will happen after 80us
	
	//TIMSK2 = 1;

	EICRA=3; // interrupt for char generator
	EIMSK=1;
	line=line_buffer[0];
ACSR=0x80;
ADCSRB=0x00;

// ADC initialization
// ADC Clock frequency: 125.000 kHz
// ADC Voltage Reference: AVCC pin
// ADC Auto Trigger Source: Free Running
// Digital input buffers on ADC0: On, ADC1: On, ADC2: On, ADC3: On
// ADC4: On, ADC5: On
DIDR0=0x00;
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0xA6;
ADCSRB&=0xF8;


	line=0; //reset the line counter

#asm("sei")

}
