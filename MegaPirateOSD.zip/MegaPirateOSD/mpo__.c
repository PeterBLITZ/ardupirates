
#include <mega88.h>
#define byte unsigned char
//volatile char tempspdr;
//#define Wait() while(!(SPSR&128)); tempspdr=SPDR



// Static functions and variables

register char tmpch @3;
register unsigned int line @4;





//===internal subroutines header
        void config(void);
        void draw_line(void);
// end header


//#pragma savereg-
register char i;
byte flag=0;
// Syncro pulse routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
	TCNT0=0; // reset timer
	TCNT2=61; // reset 80us interrupt
	while(TCNT0<180);//92); // wait 5us to see if H or V sync

	if(!(PIND.2)) { // its an H sync
		TCNT0=0; // reset timer
		line++;
		draw_line();
	}
	else { // tis a V sync
		if(line>200)line=0;
	}

}

char line_buffer[160];
char ahi_buffer[512];
#include "X_convert.c"
#define ________ 0
#define _______X 1
#define ______X_ 2
#define ______XX 3
#define _____X__ 4
#define _____X_X 5
#define _____XX_ 6
#define _____XXX 7
#define ____X___ 8
#define ____X__X 9
#define ____X_X_ 10
#define ____X_XX 11
#define ____XX__ 12
#define ____XX_X 13
#define ____XXX_ 14
#define ____XXXX 15
#define ___X____ 16
#define ___X___X 17
#define ___X__X_ 18
#define ___X__XX 19
#define ___X_X__ 20
#define ___X_X_X 21
#define ___X_XX_ 22
#define ___X_XXX 23
#define ___XX___ 24
#define ___XX__X 25
#define ___XX_X_ 26
#define ___XX_XX 27
#define ___XXX__ 28
#define ___XXX_X 29
#define ___XXXX_ 30
#define ___XXXXX 31
#define __X_____ 32
#define __X____X 33
#define __X___X_ 34
#define __X___XX 35
#define __X__X__ 36
#define __X__X_X 37
#define __X__XX_ 38
#define __X__XXX 39
#define __X_X___ 40
#define __X_X__X 41
#define __X_X_X_ 42
#define __X_X_XX 43
#define __X_XX__ 44
#define __X_XX_X 45
#define __X_XXX_ 46
#define __X_XXXX 47
#define __XX____ 48
#define __XX___X 49
#define __XX__X_ 50
#define __XX__XX 51
#define __XX_X__ 52
#define __XX_X_X 53
#define __XX_XX_ 54
#define __XX_XXX 55
#define __XXX___ 56
#define __XXX__X 57
#define __XXX_X_ 58
#define __XXX_XX 59
#define __XXXX__ 60
#define __XXXX_X 61
#define __XXXXX_ 62
#define __XXXXXX 63
#define _X______ 64
#define _X_____X 65
#define _X____X_ 66
#define _X____XX 67
#define _X___X__ 68
#define _X___X_X 69
#define _X___XX_ 70
#define _X___XXX 71
#define _X__X___ 72
#define _X__X__X 73
#define _X__X_X_ 74
#define _X__X_XX 75
#define _X__XX__ 76
#define _X__XX_X 77
#define _X__XXX_ 78
#define _X__XXXX 79
#define _X_X____ 80
#define _X_X___X 81
#define _X_X__X_ 82
#define _X_X__XX 83
#define _X_X_X__ 84
#define _X_X_X_X 85
#define _X_X_XX_ 86
#define _X_X_XXX 87
#define _X_XX___ 88
#define _X_XX__X 89
#define _X_XX_X_ 90
#define _X_XX_XX 91
#define _X_XXX__ 92
#define _X_XXX_X 93
#define _X_XXXX_ 94
#define _X_XXXXX 95
#define _XX_____ 96
#define _XX____X 97
#define _XX___X_ 98
#define _XX___XX 99
#define _XX__X__ 100
#define _XX__X_X 101
#define _XX__XX_ 102
#define _XX__XXX 103
#define _XX_X___ 104
#define _XX_X__X 105
#define _XX_X_X_ 106
#define _XX_X_XX 107
#define _XX_XX__ 108
#define _XX_XX_X 109
#define _XX_XXX_ 110
#define _XX_XXXX 111
#define _XXX____ 112
#define _XXX___X 113
#define _XXX__X_ 114
#define _XXX__XX 115
#define _XXX_X__ 116
#define _XXX_X_X 117
#define _XXX_XX_ 118
#define _XXX_XXX 119
#define _XXXX___ 120
#define _XXXX__X 121
#define _XXXX_X_ 122
#define _XXXX_XX 123
#define _XXXXX__ 124
#define _XXXXX_X 125
#define _XXXXXX_ 126
#define _XXXXXXX 127
#define X_______ 128
#define X______X 129
#define X_____X_ 130
#define X_____XX 131
#define X____X__ 132
#define X____X_X 133
#define X____XX_ 134
#define X____XXX 135
#define X___X___ 136
#define X___X__X 137
#define X___X_X_ 138
#define X___X_XX 139
#define X___XX__ 140
#define X___XX_X 141
#define X___XXX_ 142
#define X___XXXX 143
#define X__X____ 144
#define X__X___X 145
#define X__X__X_ 146
#define X__X__XX 147
#define X__X_X__ 148
#define X__X_X_X 149
#define X__X_XX_ 150
#define X__X_XXX 151
#define X__XX___ 152
#define X__XX__X 153
#define X__XX_X_ 154
#define X__XX_XX 155
#define X__XXX__ 156
#define X__XXX_X 157
#define X__XXXX_ 158
#define X__XXXXX 159
#define X_X_____ 160
#define X_X____X 161
#define X_X___X_ 162
#define X_X___XX 163
#define X_X__X__ 164
#define X_X__X_X 165
#define X_X__XX_ 166
#define X_X__XXX 167
#define X_X_X___ 168
#define X_X_X__X 169
#define X_X_X_X_ 170
#define X_X_X_XX 171
#define X_X_XX__ 172
#define X_X_XX_X 173
#define X_X_XXX_ 174
#define X_X_XXXX 175
#define X_XX____ 176
#define X_XX___X 177
#define X_XX__X_ 178
#define X_XX__XX 179
#define X_XX_X__ 180
#define X_XX_X_X 181
#define X_XX_XX_ 182
#define X_XX_XXX 183
#define X_XXX___ 184
#define X_XXX__X 185
#define X_XXX_X_ 186
#define X_XXX_XX 187
#define X_XXXX__ 188
#define X_XXXX_X 189
#define X_XXXXX_ 190
#define X_XXXXXX 191
#define XX______ 192
#define XX_____X 193
#define XX____X_ 194
#define XX____XX 195
#define XX___X__ 196
#define XX___X_X 197
#define XX___XX_ 198
#define XX___XXX 199
#define XX__X___ 200
#define XX__X__X 201
#define XX__X_X_ 202
#define XX__X_XX 203
#define XX__XX__ 204
#define XX__XX_X 205
#define XX__XXX_ 206
#define XX__XXXX 207
#define XX_X____ 208
#define XX_X___X 209
#define XX_X__X_ 210
#define XX_X__XX 211
#define XX_X_X__ 212
#define XX_X_X_X 213
#define XX_X_XX_ 214
#define XX_X_XXX 215
#define XX_XX___ 216
#define XX_XX__X 217
#define XX_XX_X_ 218
#define XX_XX_XX 219
#define XX_XXX__ 220
#define XX_XXX_X 221
#define XX_XXXX_ 222
#define XX_XXXXX 223
#define XXX_____ 224
#define XXX____X 225
#define XXX___X_ 226
#define XXX___XX 227
#define XXX__X__ 228
#define XXX__X_X 229
#define XXX__XX_ 230
#define XXX__XXX 231
#define XXX_X___ 232
#define XXX_X__X 233
#define XXX_X_X_ 234
#define XXX_X_XX 235
#define XXX_XX__ 236
#define XXX_XX_X 237
#define XXX_XXX_ 238
#define XXX_XXXX 239
#define XXXX____ 240
#define XXXX___X 241
#define XXXX__X_ 242
#define XXXX__XX 243
#define XXXX_X__ 244
#define XXXX_X_X 245
#define XXXX_XX_ 246
#define XXXX_XXX 247
#define XXXXX___ 248
#define XXXXX__X 249
#define XXXXX_X_ 250
#define XXXXX_XX 251
#define XXXXXX__ 252
#define XXXXXX_X 253
#define XXXXXXX_ 254
#define XXXXXXXX 255
//#include "oem866_6x8.c"
#include "s1d13705.c"
#define target_avr       // define for codevision; empty for builder
  #include <math.h>
#ifdef target_avr
 #define type_flash flash
 #define IBB // inverted endian in S1D13705 �����!!!!
 #define bool bit
 #define true 1
 #define false 0
// #define byte unsigned char
#else
#define type_flash const
#endif




#define CLK PORTC.0
#define ASL PORTC.1
#define ASH PORTC.2
#define WE PORTC.3
#define RD PORTC.4
#define CS PORTC.5
#define WAIT PINC.6
#define A16 PORTD.7
#define nop #asm("nop");

#define font_height 8
#define font_width 6
#define scr_height 64
#define scr_width 64
#define font_set oem6x8
//#include "X_convert_i.c" // inverted bitfields
//#include "X_convert.c" // normal font

byte char_x=0,char_y=0;
/*
flash  unsigned char b2i[256]={                 // endian swapped bits lookup
0,128,64,192,32,160,96,224,16,144,80,208,48,176,112,240,8,136,
72,200,40,168,104,232,24,152,88,216,56,184,120,248,4,132,68,
196,36,164,100,228,20,148,84,212,52,180,116,244,12,140,76,204,
44,172,108,236,28,156,92,220,60,188,124,252,2,130,66,194,34,
162,98,226,18,146,82,210,50,178,114,242,10,138,74,202,42,170,
106,234,26,154,90,218,58,186,122,250,6,134,70,198,38,166,102,
230,22,150,86,214,54,182,118,246,14,142,78,206,46,174,110,238,
30,158,94,222,62,190,126,254,1,129,65,193,33,161,97,225,17,145,
81,209,49,177,113,241,9,137,73,201,41,169,105,233,25,153,89,217,
57,185,121,249,5,133,69,197,37,165,101,229,21,149,85,213,53,
181,117,245,13,141,77,205,45,173,109,237,29,157,93,221,61,189,
125,253,3,131,67,195,35,163,99,227,19,147,83,211,51,179,115,
243,11,139,75,203,43,171,107,235,27,155,91,219,59,187,123,251,7,
135,71,199,39,167,103,231,23,151,87,215,55,183,119,247,15,143,
79,207,47,175,111,239,31,159,95,223,63,191,127,255};
*/

#include "oem866_6x8.c"
flash char oem6x8[]={ // 6x8 DOS character set
________,
________,
________,
________,
________,
________,
________,
________,
__XXX___,
_X___X__,
_XX_XX__,
_X___X__,
_X_X_X__,
_X___X__,
__XXX___,
________,
__XXX___,
_XXXXX__,
_X_X_X__,
_XXXXX__,
_X___X__,
_XXXXX__,
__XXX___,
________,
________,
__X_X___,
_XXXXX__,
_XXXXX__,
_XXXXX__,
__XXX___,
___X____,
________,
________,
___X____,
__XXX___,
_XXXXX__,
_XXXXX__,
__XXX___,
___X____,
________,
___X____,
__XXX___,
__XXX___,
___X____,
_XXXXX__,
_XXXXX__,
___X____,
________,
________,
___X____,
__XXX___,
_XXXXX__,
_XXXXX__,
___X____,
__XXX___,
________,
________,
________,
________,
__XX____,
__XX____,
________,
________,
________,
XXXXXX__,
XXXXXX__,
XXXXXX__,
XX__XX__,
XX__XX__,
XXXXXX__,
XXXXXX__,
XXXXXX__,
________,
________,
_XXXX___,
_X__X___,
_X__X___,
_XXXX___,
________,
________,
XXXXXX__,
XXXXXX__,
X____X__,
X_XX_X__,
X_XX_X__,
X____X__,
XXXXXX__,
XXXXXX__,
________,
___XXX__,
____XX__,
__XX_X__,
_X__X___,
_X__X___,
__XX____,
________,
__XXX___,
_X___X__,
_X___X__,
__XXX___,
___X____,
__XXX___,
___X____,
________,
___X____,
___XX___,
___X_X__,
___X____,
__XX____,
_XXX____,
_XX_____,
________,
____XX__,
__XX_X__,
__X_XX__,
__XX_X__,
__X_XX__,
_XX_XX__,
_XX_____,
________,
________,
_X_X_X__,
__XXX___,
_XX_XX__,
__XXX___,
_X_X_X__,
________,
________,
__X_____,
__XX____,
__XXX___,
__XXXX__,
__XXX___,
__XX____,
__X_____,
________,
____X___,
___XX___,
__XXX___,
_XXXX___,
__XXX___,
___XX___,
____X___,
________,
___X____,
__XXX___,
_XXXXX__,
___X____,
_XXXXX__,
__XXX___,
___X____,
________,
__X_X___,
__X_X___,
__X_X___,
__X_X___,
__X_X___,
________,
__X_X___,
________,
__XXXX__,
_X_X_X__,
_X_X_X__,
__XX_X__,
___X_X__,
___X_X__,
___X_X__,
________,
__XXX___,
_X___X__,
__XX____,
__X_X___,
___XX___,
_X___X__,
__XXX___,
________,
________,
________,
________,
________,
________,
_XXXX___,
_XXXX___,
________,
___X____,
__XXX___,
_XXXXX__,
___X____,
_XXXXX__,
__XXX___,
___X____,
__XXX___,
___X____,
__XXX___,
_XXXXX__,
___X____,
___X____,
___X____,
___X____,
________,
___X____,
___X____,
___X____,
___X____,
_XXXXX__,
__XXX___,
___X____,
________,
________,
___X____,
___XX___,
_XXXXX__,
___XX___,
___X____,
________,
________,
________,
___X____,
__XX____,
_XXXXX__,
__XX____,
___X____,
________,
________,
________,
________,
________,
_X______,
_X______,
_X______,
_XXXXX__,
________,
________,
__X_X___,
__X_X___,
_XXXXX__,
__X_X___,
__X_X___,
________,
________,
___X____,
___X____,
__XXX___,
__XXX___,
_XXXXX__,
_XXXXX__,
________,
________,
_XXXXX__,
_XXXXX__,
__XXX___,
__XXX___,
___X____,
___X____,
________,
________,
________,
________,
________,
________,
________,
________,
________,
________,
___X____,
__XXX___,
__XXX___,
___X____,
___X____,
________,
___X____,
________,
_XX_XX__,
_XX_XX__,
_X__X___,
________,
________,
________,
________,
________,
________,
__X_X___,
_XXXXX__,
__X_X___,
__X_X___,
_XXXXX__,
__X_X___,
________,
__X_____,
__XXX___,
_X______,
__XX____,
____X___,
_XXX____,
___X____,
________,
_XX__X__,
_XX__X__,
____X___,
___X____,
__X_____,
_X__XX__,
_X__XX__,
________,
__X_____,
_X_X____,
_X_X____,
__X_____,
_X_X_X__,
_X__X___,
__XX_X__,
________,
__XX____,
__XX____,
__X_____,
________,
________,
________,
________,
________,
___X____,
__X_____,
__X_____,
__X_____,
__X_____,
__X_____,
___X____,
________,
__X_____,
___X____,
___X____,
___X____,
___X____,
___X____,
__X_____,
________,
________,
__X_X___,
__XXX___,
_XXXXX__,
__XXX___,
__X_X___,
________,
________,
________,
___X____,
___X____,
_XXXXX__,
___X____,
___X____,
________,
________,
________,
________,
________,
________,
________,
__XX____,
__XX____,
__X_____,
________,
________,
________,
_XXXXX__,
________,
________,
________,
________,
________,
________,
________,
________,
________,
__XX____,
__XX____,
________,
________,
_____X__,
____X___,
___X____,
__X_____,
_X______,
________,
________,
__XXX___,
_X___X__,
_X__XX__,
_X_X_X__,
_XX__X__,
_X___X__,
__XXX___,
________,
___X____,
__XX____,
___X____,
___X____,
___X____,
___X____,
__XXX___,
________,
__XXX___,
_X___X__,
_____X__,
___XX___,
__X_____,
_X______,
_XXXXX__,
________,
__XXX___,
_X___X__,
_____X__,
__XXX___,
_____X__,
_X___X__,
__XXX___,
________,
____X___,
___XX___,
__X_X___,
_X__X___,
_XXXXX__,
____X___,
____X___,
________,
_XXXXX__,
_X______,
_X______,
_XXXX___,
_____X__,
_X___X__,
__XXX___,
________,
___XX___,
__X_____,
_X______,
_XXXX___,
_X___X__,
_X___X__,
__XXX___,
________,
_XXXXX__,
_____X__,
____X___,
___X____,
__X_____,
__X_____,
__X_____,
________,
__XXX___,
_X___X__,
_X___X__,
__XXX___,
_X___X__,
_X___X__,
__XXX___,
________,
__XXX___,
_X___X__,
_X___X__,
__XXXX__,
_____X__,
____X___,
__XX____,
________,
________,
________,
__XX____,
__XX____,
________,
__XX____,
__XX____,
________,
________,
________,
__XX____,
__XX____,
________,
__XX____,
__XX____,
__X_____,
____X___,
___X____,
__X_____,
_X______,
__X_____,
___X____,
____X___,
________,
________,
________,
_XXXXX__,
________,
________,
_XXXXX__,
________,
________,
__X_____,
___X____,
____X___,
_____X__,
____X___,
___X____,
__X_____,
________,
__XXX___,
_X___X__,
_____X__,
___XX___,
___X____,
________,
___X____,
________,
__XXX___,
_X___X__,
_X_XXX__,
_X_X_X__,
_X_XXX__,
_X______,
__XXX___,
________,
__XXX___,
_X___X__,
_X___X__,
_X___X__,
_XXXXX__,
_X___X__,
_X___X__,
________,
_XXXX___,
_X___X__,
_X___X__,
_XXXX___,
_X___X__,
_X___X__,
_XXXX___,
________,
__XXX___,
_X___X__,
_X______,
_X______,
_X______,
_X___X__,
__XXX___,
________,
_XXXX___,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
_XXXX___,
________,
_XXXXX__,
_X______,
_X______,
_XXXX___,
_X______,
_X______,
_XXXXX__,
________,
_XXXXX__,
_X______,
_X______,
_XXXX___,
_X______,
_X______,
_X______,
________,
__XXX___,
_X___X__,
_X______,
_X_XXX__,
_X___X__,
_X___X__,
__XXXX__,
________,
_X___X__,
_X___X__,
_X___X__,
_XXXXX__,
_X___X__,
_X___X__,
_X___X__,
________,
__XXX___,
___X____,
___X____,
___X____,
___X____,
___X____,
__XXX___,
________,
_____X__,
_____X__,
_____X__,
_____X__,
_X___X__,
_X___X__,
__XXX___,
________,
_X___X__,
_X__X___,
_X_X____,
_XX_____,
_X_X____,
_X__X___,
_X___X__,
________,
_X______,
_X______,
_X______,
_X______,
_X______,
_X______,
_XXXXX__,
________,
_X___X__,
_XX_XX__,
_X_X_X__,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
________,
_X___X__,
_XX__X__,
_X_X_X__,
_X__XX__,
_X___X__,
_X___X__,
_X___X__,
________,
__XXX___,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
__XXX___,
________,
_XXXX___,
_X___X__,
_X___X__,
_XXXX___,
_X______,
_X______,
_X______,
________,
__XXX___,
_X___X__,
_X___X__,
_X___X__,
_X_X_X__,
_X__X___,
__XX_X__,
________,
_XXXX___,
_X___X__,
_X___X__,
_XXXX___,
_X__X___,
_X___X__,
_X___X__,
________,
__XXX___,
_X___X__,
_X______,
__XXX___,
_____X__,
_X___X__,
__XXX___,
________,
_XXXXX__,
___X____,
___X____,
___X____,
___X____,
___X____,
___X____,
________,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
__XXX___,
________,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
_X___X__,
__X_X___,
___X____,
________,
_X___X__,
_X___X__,
_X_X_X__,
_X_X_X__,
_X_X_X__,
_X_X_X__,
__X_X___,
________,
_X___X__,
_X___X__,
__X_X___,
___X____,
__X_X___,
_X___X__,
_X___X__,
________,
_X___X__,
_X___X__,
_X___X__,
__X_X___,
___X____,
___X____,
___X____,
________,
_XXXX___,
____X___,
___X____,
__X_____,
_X______,
_X______,
_XXXX___,
________,
__XXX___,
__X_____,
__X_____,
__X_____,
__X_____,
__X_____,
__XXX___,
________,
________,
_X______,
__X_____,
___X____,
____X___,
_____X__,
________,
________,
__XXX___,
____X___,
____X___,
____X___,
____X___,
____X___,
__XXX___,
________,
___X____,
__X_X___,
_X___X__,
________,
________,
________,
________,
________,
________,
________,
________,
________,
________,
________,
________,
XXXXXX__,
__XX____,
__XX____,
___X____,
________,
________,
________,
________,
________,
________,
________,
__XXX___,
_____X__,
__XXXX__,
_X___X__,
__XXXX__,
________,
_X______,
_X______,
_XXXX___,
_X___X__,
_X___X__,
_X___X__,
_XXXX___,
________,
________,
________,
__XXX___,
_X___X__,
_X______,
_X___X__,
__XXX___,
________,
_____X__,
_____X__,
__XXXX__,
_X___X__,
_X___X__,
_X___X__,
__XXXX__,
________,
________,
________,
__XXX___,
_X___X__,
_XXXX___,
_X______,
__XXX___,
________,
___XX___,
__X_____,
__X_____,
_XXXX___,
__X_____,
__X_____,
__X_____,
________,
________,
________,
__XXXX__,
_X___X__,
_X___X__,
__XXXX__,
_____X__,
__XXX___,
_X______,
_X______,
_XXX____,
_X__X___,
_X__X___,
_X__X___,
_X__X___,
________,
___X____,
________,
___X____,
___X____,
___X____,
___X____,
___XX___,
________,
____X___,
________,
___XX___,
____X___,
____X___,
____X___,
_X__X___,
__XX____,
_X______,
_X______,
_X__X___,
_X_X____,
_XX_____,
_X_X____,
_X__X___,
________,
___X____,
___X____,
___X____,
___X____,
___X____,
___X____,
___XX___,
________,
________,
________,
_XX_X___,
_X_X_X__,
_X_X_X__,
_X___X__,
_X___X__,
________,
________,
________,
_XXX____,
_X__X___,
_X__X___,
_X__X___,
_X__X___,
________,
________,
________,
__XXX___,
_X___X__,
_X___X__,
_X___X__,
__XXX___,
________,
________,
________,
_XXXX___,
_X___X__,
_X___X__,
_X___X__,
_XXXX___,
_X______,
________,
________,
__XXXX__,
_X___X__,
_X___X__,
_X___X__,
__XXXX__,
_____X__,
________,
________,
_X_XX___,
__X__X__,
__X_____,
__X_____,
_XXX____,
________,
________,
________,
__XXX___,
_X______,
__XXX___,
_____X__,
__XXX___,
________,
________,
__X_____,
_XXXX___,
__X_____,
__X_____,
__X_X___,
___X____,
________,
________,
________,
_X__X___,
_X__X___,
_X__X___,
_X_XX___,
__X_X___,
________,
________,
________,
_X___X__,
_X___X__,
_X___X__,
__X_X___,
___X____,
________,
________,
________,
_X___X__,
_X___X__,
_X_X_X__,
_XXXXX__,
__X_X___,
________,
________,
________,
_X__X___,
_X__X___,
__XX____,
_X__X___,
_X__X___,
________,
________,
________,
_X__X___,
_X__X___,
_X__X___,
__XXX___,
___X____,
_XX_____,
________,
________,
_XXXX___,
____X___,
__XX____,
_X______,
_XXXX___,
________,
___XX___,
__X_____,
__X_____,
_XX_____,
__X_____,
__X_____,
___XX___,
________,
___X____,
___X____,
___X____,
________,
___X____,
___X____,
___X____,
________,
__XX____,
____X___,
____X___,
____XX__,
____X___,
____X___,
__XX____,
________,
__X_X___,
_X_X____,
________,
________,
________,
________,
________,
________,
___X____,
__XXX___,
_XX_XX__,
_X___X__,
_X___X__,
_XXXXX__,
________,
________
};

void lcd_msg1(type_flash char *text);
void beeper(byte beeep);










byte l_mask_array[8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

void lcd_setpixel( short x,  short y, char pcolor) // pixel color: 1-set, 0-clear, 2-toggle
{unsigned short byte_off;
char bit_off,tmpc;
if (x>=scr_width) return;
if (x<0) return;
if (y>=scr_height) return;
if (y<0) return;
byte_off=(x>>3)+y*(scr_width>>3);
bit_off=x & 7;
tmpc=ahi_buffer[byte_off];
if (pcolor==1) tmpc |= (l_mask_array[bit_off]);
if (pcolor==0) tmpc &= (l_mask_array[bit_off]) ^ 255 ;
if (pcolor==2) tmpc ^= (l_mask_array[bit_off]);
ahi_buffer[byte_off]=tmpc;
return;}

/*
flash unsigned char a2o[256] = {
0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
0xFF, 0xF6, 0xF7, 0x20, 0xFD, 0xF2, 0x7C, 0x20, 0xF0, 0x20, 0xF4, 0x20, 0x20, 0x20, 0x20, 0xF8,
0xF8, 0xB1, 0xF6, 0xF7, 0xF3, 0x20, 0x20, 0xFA, 0xF1, 0xFC, 0xF5, 0x20, 0x20, 0x20, 0x20, 0xF9,
0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x8D, 0x8E, 0x8F,
0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xDB, 0x9C, 0x9D, 0x9E, 0x9F,
0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF
};
*/
/*static unsigned char o2a[256] = {
0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF,
0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF,
0x2D, 0x2D, 0x2D, 0x7C, 0x2B, 0x7C, 0x7C, 0x2D, 0x2D, 0x7C, 0x7C, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D,
0x2D, 0x2B, 0x2D, 0x2B, 0x2D, 0x2B, 0x7C, 0x7C, 0x2D, 0x2D, 0x7C, 0x2D, 0x7C, 0x3D, 0x2B, 0x7C,
0x7C, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 0x2B, 0x2B, 0x2D, 0x2D, 0x2D, 0x2D, 0x7C, 0x7C, 0x2D,
0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF,
0xA8, 0xB8, 0xA5, 0xB4, 0xAA, 0xBA, 0xB2, 0xB3, 0xAF, 0xBF, 0xB7, 0xFB, 0xB9, 0xA4, 0xFE, 0xA0
};
  */


/*
void lcd_oemchar (byte glyph1) // put a char to the position. Color 0-normal, 1-inverted, 2-XOR
{unsigned short byte_off;
long bit_off;
byte bit_rem;
unsigned char tmpc,tmpz,icnt;
byte glyph;
unsigned short pchr;
glyph=a2o[glyph1];

bit_off=char_x+char_y*scr_width;
bit_rem=bit_off&7; // 00000001
if (bit_rem==0)
{
        byte_off=bit_off>>3;
        pchr=(short)glyph*font_height;
                for (icnt=0;icnt<font_height;icnt++)
                        {tmpc=b2i[font_set[pchr]]; pchr++;
                        tmpc |= ahi_buffer[byte_off];
                        ahi_buffer[byte_off]=tmpc;
                        byte_off+=scr_width>>3; // columns
                        }



}
else // 2 bytes split in halves
{
        byte_off=bit_off>>3;
        pchr=(short)glyph*font_height;
                for (icnt=0;icnt<font_height;icnt++)
                        {tmpc=b2i[font_set[pchr]]; pchr++;
                        tmpz=tmpc<<bit_rem;
                        tmpz |= ahi_buffer[byte_off];
                        ahi_buffer[byte_off]=tmpz;
                        tmpz=tmpc>>(8-bit_rem);
                        tmpz |= ahi_buffer[byte_off+1];
                        ahi_buffer[byte_off+1]=tmpz;

                        byte_off+=scr_width>>3; // columns
                        }





}
char_x+=font_width;
return;}
*/


 /*
void lcd_print(type_flash char *text) // curcol,currow,mode 0-normal,1-inverted,2-XOR
{char disp=0;
char tmpc;
while(*(text+disp)!=0)
{tmpc=*(text+disp);

lcd_oemchar(tmpc); // inc posn
disp++;
}
return;}
   */

void lcd_line(  short x1,  short y1,  short x2,  short y2,   short mode )
{
    int deltaX = abs(x2 - x1);
    int deltaY = abs(y2 - y1);
    int signX = x1 < x2 ? 1 : -1;
    int signY = y1 < y2 ? 1 : -1;
    int error = deltaX - deltaY;
    int error2;

    for (;;)
    {
        lcd_setpixel(x1, y1,mode);

        if(x1 == x2 && y1 == y2)
            break;

        error2 = error * 2;

        if(error2 > -deltaY)
        {
            error -= deltaY;
            x1 += signX;
        }

        if(error2 < deltaX)
        {
            error += deltaX;
            y1 += signY;
        }
    }
}

void lcd_circle(short xCenter, short yCenter, short radius, short mode)
 {  short tSwitch, y, x = 0;
    short d;
   d = yCenter - xCenter;
   y = radius;
   tSwitch = 3 - 2 * radius;
   while (x <= y)
    { lcd_setpixel(xCenter + x, yCenter + y, mode);
      lcd_setpixel(xCenter + x, yCenter - y, mode);
     lcd_setpixel(xCenter - x, yCenter + y, mode);
      lcd_setpixel(xCenter - x, yCenter - y, mode);
      lcd_setpixel(yCenter + y - d, yCenter + x, mode);
      lcd_setpixel(yCenter + y - d, yCenter - x, mode);
      lcd_setpixel(yCenter - y - d, yCenter + x, mode);
      lcd_setpixel(yCenter - y - d, yCenter - x, mode);
      if (tSwitch < 0)  tSwitch += (4 * x + 6);  else  { tSwitch += (4 * (x - y) + 10); y--; }
      x++;
    }
 }

 // tbitmap



// #include "pix.c"
/*void lcd_bmp(type_flash char *pix, char y, char x, char pmode) // mode 0-norm,1-inv,2-xor
// picture format: width,height,[bitmap]
{unsigned short tmc,x2,y2,baseoff;
char tmw,tmh,tmpc;
baseoff=x+(short)y*40*font_height; // base offset for x and y
tmw=(*pix)>>3; //width in bytes
tmh=*(pix+1) ;//height
tmc=2;
for (y2=0;y2<tmh;y2++)
{for (x2=0;x2<tmw;x2++)
     {
tmpc= *(pix+tmc);
if (pmode==2) tmpc ^= lcd_getb(0,baseoff);
if (pmode==1) tmpc ^=255;
lcd_putb(0,baseoff, tmpc);
baseoff++;
tmc++;
     }
baseoff+=40-tmw;
 }
return;} */
/*
void lcd_drawbox(unsigned short x,unsigned short y,unsigned short dispx,unsigned short dispy,char pmode)
{
lcd_line(x,y,x,y+dispy,pmode);
lcd_line(x,y,x+dispx,y,pmode);
lcd_line(x+dispx,y+dispy,x,y+dispy,pmode);
lcd_line(x+dispx,y+dispy,x+dispx,y,pmode);
return;}


void lcd_fillbox(unsigned short x,unsigned short y,unsigned short dispx,unsigned short dispy,char pmode)
{
unsigned short i,j;
i=y;j=y+dispy;
while (i<j)
{lcd_line(x,i,x+dispx,i,pmode);
i++;}
return;

}
*/
void intos(int x,long num,byte dig,byte zeros,byte zpt) // pmode 5: into buffer
{
byte cpush,leadz=0;
unsigned short div;
unsigned long rem;

if (num<0){num=-num;line_buffer[x++]='-';}
else line_buffer[x++]=' ';



rem=num;
if (dig>=7)
{
div=rem/1000000;
if (div) leadz=1;
rem-=1000000*div;
if (div | zeros| leadz|(zpt==6)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==6) line_buffer[x++]='.';
if (dig>=6)
{
div=rem/100000;
if (div) leadz=1;
rem-=100000*div;
if (div | zeros| leadz|(zpt==5)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==5) line_buffer[x++]='.';
if (dig>=5)
{
div=rem/10000;
if (div) leadz=1;
rem-=10000*div;
if (div | zeros | leadz|(zpt==4)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==4) line_buffer[x++]='.';
if (dig>=4)
{
div=rem/1000;
if (div) leadz=1;
rem-=1000*div;
if (div | zeros| leadz|(zpt==3)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==3) line_buffer[x++]='.';
if (dig>=3)
{
div=rem/100;
if (div) leadz=1;
rem-=100*div;
if (div | zeros| leadz|(zpt==2)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==2) line_buffer[x++]='.';
if (dig>=2)
{
div=rem/10;
if (div) leadz=1;
rem-=10*div;
if (div | zeros| leadz|(zpt==1)) {line_buffer[x++]=(div+0x30);}
}
if (zpt==1) line_buffer[x++]='.';

line_buffer[x++]=((byte)rem+0x30);
}



/*
void lcd_arc(void) // �������� :)
{
signed int bx[30]={20,20,70,140,100,164,20,34,85,100,164,20,20,100,164,20,34,85,130,20,70,140,20,34,85,130,130,20,70,140};
signed int by[30]={100,164,50,100,164,20,100,164,20,34,185,30,120,70,40,50,120,70,40,20,34,185,30,34,185,30,120,70,40,50};
signed int br[30]={3,7,4,3,7,4,3,8,6,8,6,9,3,8,3,7,4,3,8,6,5,3,8,3,9,5,9,5,3,8};
signed int dbx[30]={1,-1,2,-1,2,1,-1,3,-1,1,3,-1,2,3,-1,3,1,-2,1,-2,-1,-2,-1,-2,1,1,2,-2,-1,-3};
signed int dby[30]={-5,-4,-2,-4,-2,-3,-3,-2,-3,-2,-3,-4,-2,-2,-2,-3,-3,-2,-2,-2,-4,-3,-2,-2,-3,-4,-4,-2,-2,-2};
byte ccnt;
int bxt,byt;

long k;
lcd_cls();

ccnt=25;while (ccnt){lcd_circle(bx[ccnt],by[ccnt],br[ccnt],1);ccnt--;}
arc_lp01:
ccnt=25;while (ccnt){
lcd_circle(bx[ccnt],by[ccnt],br[ccnt],0);
bxt=bx[ccnt]+dbx[ccnt];
byt=by[ccnt]+dby[ccnt];
if ((bxt>320)|(bxt<0)) dbx[ccnt]=-dbx[ccnt];
if ((byt>240)|(byt<0)) by[ccnt]=240;//dby[ccnt]=-dby[ccnt];
bx[ccnt]+=dbx[ccnt];
by[ccnt]+=dby[ccnt];
lcd_circle(bx[ccnt],by[ccnt],br[ccnt],1);
ccnt--;}
curcol=5;
currow=10;
lcd_print("���� ������. ������� ����� ������",0);
curcol=13;
currow=11;
keyscan();
if (keybuf<6) return;//lcd_print("�����",0);
k=10;
while (k)
{k--;}

goto arc_lp01;
}

 */
//void lcd_dispframe






// Timer 2 overflow interrupt service routine // each 80 us, 2MHz tick
interrupt [TIM2_OVF] void timer2_ovf_isr(void)
{
// Place your code here
	TCNT2=177; // reset 80us interrupt
	//if (UCSR0A & (1<<RXC0)) MsgHandler(UDR0); //poll the serial port

}

// Declare your global variables here
int xx;
//==================================================

void lcd_cls(void)
{for (xx=0;xx<511;xx++)
ahi_buffer[xx]=0x0;
for (xx=0;xx<80;xx++)
line_buffer[xx]=0x0;
}
 //==================================================

void print(int pos,flash char *text)
{
int disp=0;
while(*(text+disp)!=0)
{line_buffer[pos+disp]=*(text+disp);
disp++;}
}
//==================================================

void draw_homebird(int hdg)
{
char j; // position from 0 to 63
if(hdg>179) hdg=hdg-360;
j=32-((hdg)*64)/360;

       // j=hdg;
 // central pixel
 lcd_setpixel(j,3,1);
 lcd_setpixel(j+1,4,1);
 lcd_setpixel(j-1,4,1);
 lcd_setpixel(j+2,5,1);
 lcd_setpixel(j-2,5,1);
}
//==================================================

void draw_pitchbird(int hdg)
{
byte j; // position from 0 to 63
// pitch from -31 to +31
if (hdg< -31) hdg=-31;
if (hdg> 31) hdg=31;
 j=32+hdg;

 // central pixel
 lcd_setpixel(60,j,1);
 lcd_setpixel(59,j+1,1);
 lcd_setpixel(59,j-1,1);
 lcd_setpixel(58,j+2,1);
 lcd_setpixel(58,j-2,1);
}
//==================================================
void draw_ahiline(int roll)
{float sinr,cosr;
// line length 20
sinr=sin(roll*0.03488);
cosr=cos(roll*0.03488);
lcd_line(32-20*cosr,32+20*sinr,32+20*cosr,32-20*sinr,1);
lcd_line(32,32,32-8*sinr,32-8*cosr,1);
}

#define ADC_VREF_TYPE 0x40

void display_vbat(void)
{ int jj;
ADMUX=1 | (ADC_VREF_TYPE & 0xff);
// Start the AD conversion
ADCSRA|=0x40;
// Wait for the AD conversion to complete
while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;

jj=ADCW;
jj=jj*3;
intos(0,jj,4,0,2); // print battery voltage (5 digs)
print(6,"V");





}

// process rx commands

//==================================================

byte statZ=0;

byte syncro=0xcb,pkt_ctr=0,pkt_type=0;
byte rx_buf[11],pak_buf0[11],pak_buf1[11],pak_buf2[11];
byte icnt,tmpr;
void receive_rx(void)
{
/*buffer format:
0-sync word changed (0xcb, 0x34)
1  packet type (0 - ahi,bat,cur,mah, 1 - nav, 2 - maintenance
2       0               1               2
3       roll            gpslat1         gpsSPD
4       pitch           gpslat2         gpsALTH
5       homeH           gpslat3         gpaALTL
6       homeL           gpslat4         gpsDISH
7       control_mode    gpslon1         gpsDISL
8       BATl            gpslon2         status
9       Ih              gpslon3         config
10      IL (up 80.0A)   gpslon4         emerg


==
status:
0..3
        0-Manual
*/

// this routine is called when received 1 byte
// 11 bytes length

tmpr=UDR0;
statZ=tmpr;
        switch (pkt_type)
        {case 0: pak_buf0[pkt_ctr]=tmpr;break;
         case 1: pak_buf1[pkt_ctr]=tmpr;break;
         case 2: pak_buf2[pkt_ctr]=tmpr;break;
        }
if (pkt_ctr==0) //first byte received
        {if (tmpr==syncro) {pkt_ctr++;syncro^=255;}}
                //else dont increase
else pkt_ctr++; // non-first byte received
if(pkt_ctr==2) pkt_type=tmpr;
if (pkt_ctr==11) pkt_ctr=0; // end of packet

}

//==================================================
// graphic variables
signed char v_pitch=0,v_roll=0;
signed int v_home=0;
//==================================================

void process0(void) // process the packet0
{
/*
0-sync word changed (0xcb, 0x34)
1  packet type (0 - ahi,bat,cur,mah, 1 - nav, 2 - maintenance
2       0
3       roll
4       pitch
5       homeH
6       homeL
7       control_mode
8       0
9       Ih
10      IL (up 80.0A)
*/
v_roll=pak_buf0[3];
v_pitch=pak_buf0[4];
v_home=((int)pak_buf0[5]<<8)|pak_buf0[6];
switch(pak_buf0[7])
        {case 0: print(30,"MANUAL");break;
         case 1: print(30,"CIRCLE");break;
        case 2: print(30,"STABILIZE");break;
        case 5: print(30,"WIRE A");break;
        case 6: print(30,"WIRE B");break;
        case 10: print(30,"AUTOPILOT");break;
        case 11: print(30,"RETURN");break;
        case 12: print(30,"HOLD");break;
        case 13: print(30,"TAKEOFF");break;
        case 14: print(30,"LANDING");break;


        }

/*
#define MANUAL 0
#define CIRCLE 1
#define STABILIZE 2

#define FLY_BY_WIRE_A 5
#define FLY_BY_WIRE_B 6

#define AUTO 10
#define RTL 11
#define LOITER 12
#define TAKEOFF 13
#define LAND 14
*/
intos(40,((int)pak_buf0[9]<<8)|pak_buf0[10],3,0,1); // print current (5 digs)
print(45,"A");
}
//==================================================




byte time_sec=0;
byte time_sec1=0;
byte time_min=0;
byte time_min1=0;
byte time_hr=0;

void count_time(void) // 50Hz
{static char cnt=0;
cnt++;
if (cnt<50) return;
cnt=0;
time_sec++; if (time_sec>9) {time_sec=0;time_sec1++;}
if (time_sec1>5) {time_sec1=0;time_min++;}
if (time_min>9) {time_min=0;time_min1++;}
if (time_min1>5) {time_min1=0;time_hr++;}
}


void main(void)
{
config();
SMCR=1;
lcd_cls();
//print(0, "10.7V 5400mAh    Dis11500      AUTOPILOT");
//print(40,"20.4A    SPD 178   ALT 2500    HDOP 1.2 ");
print(0, "                                        ");
print(40,"                                        ");


while(1)
{// loop

if (flag)     //50 Hz
{
  flag=0;
  lcd_cls();
  count_time();
  line_buffer[1]++;
// draw scales and crosshair
for(i=0;i<64;i+=4)
lcd_setpixel(i,0,1);
for(i=0;i<64;i+=16) // upper scale (home)
{lcd_setpixel(i,1,1);
lcd_setpixel(i,2,1);}

for(i=0;i<64;i+=4) // right scale (pitch)
lcd_setpixel(63,i,1);
for(i=0;i<64;i+=16) //
{lcd_setpixel(62,i,1);
lcd_setpixel(61,i,1);}

// home bird
draw_homebird(v_home);
draw_pitchbird(v_pitch);
lcd_circle(32,32,2,1);
draw_ahiline(v_roll);

process0();
display_vbat();


// print clocks at line2
line_buffer[56]=time_hr+0x30;
line_buffer[57]=':';
line_buffer[58]=time_min1+0x30;
line_buffer[59]=time_min+0x30;
line_buffer[60]=':';
line_buffer[61]=time_sec1+0x30;
line_buffer[62]=time_sec+0x30;




 }

#asm
sleep
#endasm
} // end main loop
}








	#define graf_dsp    135


//***************************Line drawing routine
// 2x40 line buffer
// 64x64 graphics buffer
void draw_line(void)
{
#asm("push r31 push r30");
if(line==30){	SPCR = (1<<6) | (1<<4) | (1<<2);}
	if ((line >= 40) && (line < (48))) // 1st line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<213); //wait ~7.5us from H-sync
	        tmpch=line-40;// R3
	        DDRB.1=1;
		PORTB.1=0;
        #asm
clr r15 // zero register
ldi r18,40   // counter downto 0
ldi r27,high(_line_buffer)
ldi r26,low(_line_buffer) // XL
ldi r17,8
        // main cycle: spdr=oem6x8[8*line_buffer[cnt]+subline]
write_str:
ld r16,X+ mul r16,r17 // line_buffer[cnt]*8
clc ldi r31,high(2*_oem6x8) ldi r30,low(2*_oem6x8)  // ZL
add r30,r0 adc r31,r1 clc add r30,r3 adc r31,r15
lpm r16,Z out SPDR,r16 dec r18 brne write_str
//        wait_t:
//        in r16,SPSR sbrs r19,7 rjmp wait_t in r16,SPDR
#endasm
TCNT0=0;
while(TCNT0<20);
	        DDRB.1=0;
	}

	else if ((line >= 52) && (line < (60))) // 2nd line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<203); //wait ~7.5us from H-sync  // 10 pts each condition
	        tmpch=line-52;// R3
	        DDRB.1=1;
		PORTB.1=0;
        #asm
clr r15 // zero register
ldi r18,40   // counter downto 0
ldi r27,high(_line_buffer+40)
ldi r26,low(_line_buffer+40) // XL
ldi r17,8
        // main cycle: spdr=oem6x8[8*line_buffer[cnt]+subline]
write_str1:
ld r16,X+ mul r16,r17 // line_buffer[cnt]*8
clc ldi r31,high(2*_oem6x8) ldi r30,low(2*_oem6x8)  // ZL
add r30,r0 adc r31,r1 clc add r30,r3 adc r31,r15
lpm r16,Z out SPDR,r16 dec r18 brne write_str1
//        wait_t:
//        in r16,SPSR sbrs r19,7 rjmp wait_t in r16,SPDR
#endasm
TCNT0=0;
while(TCNT0<20);
DDRB.1=0;
	}
//##################### Graphics 64x64
	else if ((line >= graf_dsp) && (line < (graf_dsp+64))) // 2nd line of 40 chars 8x8
	{
		TCNT0=0;
		while(TCNT0<218); //wait ~7.5us from H-sync  // 10 pts each condition
		TCNT0=0;
		while(TCNT0<214); //wait ~7.5us from H-sync  // 10 pts each condition
	        tmpch=line-graf_dsp;// R3
	        DDRB.1=1;
	        PORTB.1=0;
		//PORTB.1=1;
        #asm
ldi r18,8   // counter downto 0
ldi r27,high(_ahi_buffer)
ldi r26,low(_ahi_buffer) // XL
ldi r17,8
mul r3,r17
add r26,r0
adc r27,r1
        // main cycle: spdr=ahi_buffer[8*r3+r18]
#define _PORTB 5
write_str2:
ld r16,X+
rol r16
out _PORTB,r16
nop
nop
ror r16
out _PORTB,r16
nop
nop
ror r16
out _PORTB,r16
nop
nop
ror r16
out _PORTB,r16
nop
nop
ror r16
out _PORTB,r16
nop
nop
ror r16
out _PORTB,r16
nop
nop
ror r16
out _PORTB,r16
nop
ror r16
dec r18
out _PORTB,r16
brne write_str2
#endasm
PORTB.1=0;
DDRB.1=0;

	}else if (line==graf_dsp+64) {flag=1;}


if(UCSR0A&128) receive_rx();


#asm("pop r30 pop r31");

//***************************end Line drawing routine
}














void config(void)
{
	// PORT B - Video Out
	//PB0 used for background dimming
	PORTB = 0x00;							// Initial state is everything off
	DDRB  = 0x3d;							// Data direction register for port B
        DDRB.1=1;
	// PORT D - Not really used
	//	Bit/Pin 2 (out) connected the control line on a servo
	PORTD = 0x00;							// Initial state is everything off
	DDRD  = 0x00;							// Data direction register for port D

	//enable the SPI port
	SPDR = 0; //CLEAR THE SPI DATA REGISTER!!! OR WILL HOSE THE VIDEO RANDOMLY IF NOT CLEARED!
	SPCR = (1<<6) | (1<<4) | (1<<2);
	SPSR = 1;

	// Set baud rate of USART to 9600 baud at 8 MHz
UCSR0A=0x00;
UCSR0B=0x10;
UCSR0C=0x06;
UBRR0H=0x00;
UBRR0L=0x9f;//0x33;

	// Setup idle mode sleeps

	//set_sleep_mode(SLEEP_MODE_IDLE);

	TCCR0B = 0x01; //enable timer w/ no prescaling

	TCCR2B = 0x02; //enable timer with /8 prescale
	TCNT2 = 84; //overflow will happen after 80us

	//TIMSK2 = 1;

	EICRA=3; // interrupt for char generator
	EIMSK=1;
	line=line_buffer[0];
ACSR=0x80;
ADCSRB=0x00;

// ADC initialization
// ADC Clock frequency: 125.000 kHz
// ADC Voltage Reference: AVCC pin
// ADC Auto Trigger Source: Free Running
// Digital input buffers on ADC0: On, ADC1: On, ADC2: On, ADC3: On
// ADC4: On, ADC5: On
DIDR0=0x00;
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0xA6;
ADCSRB&=0xF8;


	line=0; //reset the line counter

#asm("sei")

}
