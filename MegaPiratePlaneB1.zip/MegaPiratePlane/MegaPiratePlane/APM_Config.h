//MegaPirate Plane configuration file

//uncomment this if you have no GPS and want to speed up the start
//#define GPS_PROTOCOL GPS_PROTOCOL_NONE


//uncomment this and select the proper port speed to use the XBee or APC220 telemetry
//#define SERIAL3_BAUD        57600
//#define GCS_PORT            3

//###################### GPS HOME setting
// Uncomment the next line to enable automatic GPS home fix on powerup

#define AUTO_HOME_ENABLED

//select minimal satellite count to lock the GPS home position
#define HOME_sat_count 6

// select countdown duration before fix after min. sat count was reached
#define HOME_countdown 5


//#################################

//===========================================================
/* select your plane configuration (instead of the onboard switches)  */

#define AILERON_REVERSED  // reverse ailerons // both elevons in the elevon mode
#define ELEVATOR_REVERSED // reverse elevator // left elevon in the elevon mode
//#define RUDDER_REVERSED    //  reverse rudder   // right elevon in the elevon mode
//#define ELEVON_MIXER 		// AIL - left elevon, ELE - right elevon


#define FLIGHT_MODE_CHANNEL 5 // You can move your flight mode channel to any appropriate ch from 5 to 8

