 
 // -*- tab-width: 4; Mode: C++; c-basic-offset: 4; indent-tabs-mode: nil -*-

// This file is just a placeholder for your configuration file.  If you wish to change any of the setup parameters from
// their default values, place the appropriate #define statements here.


//uncomment this and select the proper port speed to use the XBee telemetry
/*
#define SERIAL3_BAUD        38400
#define GCS_PORT            3
*/
//===========================================================
/* select your plane configuration (instead of the onboard switches)  */

//#define AILERON_REVERSED  // reverse ailerons // both elevons in the elevon mode
#define ELEVATOR_REVERSED // reverse elevator // left elevon in the elevon mode
//#define RUDDER_REVERSED    //  reverse rudder   // right elevon in the elevon mode
//#define ELEVON_MIXER 		// AIL - left elevon, ELE - right elevon


#define FLIGHT_MODE_CHANNEL 5 // You can move your flight mode channel to any appropriate ch from 5 to 8
