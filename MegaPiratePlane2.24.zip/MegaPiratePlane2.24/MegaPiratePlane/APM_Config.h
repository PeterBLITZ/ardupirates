//############################################################################
// ########## Telemetry Control ##############################################
//############################################################################

// Select telemetry port speed
// If the speed selected is less than 115200, telemetry data streams
// are forced to no more than 3.3 Hz update rate
#define SERIAL3_BAUD        57600

// This parameter is reducing the overall data rate on the low-speed wireless telemetry.
// When being enabled, several exhaustive parameters such as raw sensors, raw GPS etc
// would not be transmitted.
// Options are ENABLED/DISABLED
#define REDUCED_PROTOCOL     ENABLED

//############################################################################
// ########## GPS auto home acquisition ######################################
//############################################################################
// Uncomment the next line to enable automatic GPS home fix on powerup

#define AUTO_HOME_ENABLED

//select minimal satellite count to lock the GPS home position
#define HOME_sat_count 6

// select countdown duration before fix after min sat count was reached
// in seconds
#define HOME_countdown 10

//===============================






//############################################################################
// ########## Flight channel mixer for MegaPirate Plane by Syberian ##########
//############################################################################

// Set the channel mixing in percents from the middle point (1500)
// The range is -120 to +120 percents; Set 0 to skip the channel
// Set percentage <>0 to several channels to mix them together
// set -100 to reverse the channel (subtrims are also apply)
// Output names are corresponding to Black Vortex board

// ### Be careful with throttle mixing with other channels! - thay have different center points
// ### Channels with the total range >100% will be saturated in their extremal positions


//Example of the elevon mixer on the CH1,2:
//           Roll  Pitch  Throttle  Rudder Ch_5 Ch_6
///* CH1 */  -50,  50,     0,      0,   0,   0,
///* CH2 */  50,  50,   0,      0,   0,   0,

//Example of the Pitch+throttle mixer on the CH2
// (pitch down to compensate throttle)
//           Roll  Pitch  Throttle  Rudder Ch_5 Ch_6 
///* CH2 */  0,    100,   -10,      0,   0,   0,




long mxt[]={
//           Roll  Pitch  Throttle  Rudder Ch_5 Ch_6

/* CH1 */    -100,  0,    0,        0,     0,   0,
/* CH2 */    0,    -100,  0,        0,     0,   0,
/* CH3 */    0,    0,     100,      0,     0,   0,
/* CH4 */    0,    0,     0,        100,   0,   0,
/* CH5 */    0,    0,     0,        0,     100, 0,
/* CH6 */    0,    0,     0,        0,     0,   100

};


