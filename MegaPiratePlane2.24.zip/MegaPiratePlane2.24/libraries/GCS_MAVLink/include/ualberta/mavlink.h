/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Friday, August 5 2011, 07:37 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "ualberta.h"

#endif
