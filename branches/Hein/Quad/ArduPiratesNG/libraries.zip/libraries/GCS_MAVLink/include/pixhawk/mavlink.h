/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Tuesday, December 7 2010, 13:34 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "pixhawk.h"

#endif
