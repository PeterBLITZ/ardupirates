// -*- tab-width: 4; Mode: C++; c-basic-offset: 4; indent-tabs-mode: t -*-

// Assorted useful math operations for ArduPilot(Mega)

#include "vector2.h"
#include "vector3.h"
#include "matrix3.h"
