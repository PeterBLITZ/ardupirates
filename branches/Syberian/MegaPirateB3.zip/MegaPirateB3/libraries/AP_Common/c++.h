#ifndef CPP_H
#define CPP_H

void displayMemory();
int freeMemory();

#endif
