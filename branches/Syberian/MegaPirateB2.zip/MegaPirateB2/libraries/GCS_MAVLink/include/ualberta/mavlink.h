/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Saturday, April 16 2011, 04:02 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "ualberta.h"

#endif
