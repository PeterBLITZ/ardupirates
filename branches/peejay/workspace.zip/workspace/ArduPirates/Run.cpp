//Includes for compiling outside of Arduino IDE

/*  DCM.pde   */
void Normalize(void);
void Drift_correction(void);
void Accel_adjust(void);
void Matrix_update(void);
void Euler_angles(void);
float Vector_Dot_Product(float vector1[3],float vector2[3]);
void Vector_Cross_Product(float vectorOut[3], float v1[3],float v2[3]);
void Vector_Scale(float vectorOut[3],float vectorIn[3], float scale2);
void Vector_Add(float vectorOut[3],float vectorIn1[3], float vectorIn2[3]);
void Matrix_Multiply(float a[3][3], float b[3][3],float mat[3][3]);

/* Functions.pde  */
void RadioCalibration();
void comma();

/*  Log.pde  */
void Log_Write_Sensor(int s1, int s2, int s3,int s4, int s5, int s6, int s7);
void Log_Write_Attitude(int log_roll, int log_pitch, int log_yaw);
void Log_Write_PID(char num_PID, int P, int I,int D, int output);
void Log_Write_GPS(long log_Time, long log_Lattitude, long log_Longitude, long log_Altitude,
                  long log_Ground_Speed, long log_Ground_Course, char log_Fix, char log_NumSats);
void Log_Write_Radio(int ch1, int ch2, int ch3,int ch4, int ch5, int ch6);
void Log_Read_Sensor();
void Log_Read_Attitude();
void Log_Read_PID();
void Log_Read_GPS();
void Log_Read_Radio();
void Log_Read(int start_page, int end_page);

/*  Navidation.pde  */
void Position_control(long lat_dest, long lon_dest);
int Altitude_control_Sonar(int Sonar_altitude, int target_sonar_altitude);
int Altitude_control_Sonar_v2(int Sonar_altitude, int target_sonar_altitude, float az_f);
int Altitude_control_baro(long altitude, long target_altitude);
int Altitude_control_baro_v2(long altitude, long target_altitude);

/*  Sensors  */
void Update_Sensors(void);
int Raw_Sensor_Read(char n);
void Calibrate_Gyro_Offsets(void);
int Sonar_Sensor_Filter(long new_value, int old_value, int max_diff);
long BMP_Sensor_Filter(long new_value, long old_value, int max_diff);
void read_airspeed(void);
void read_battery(void);
void zero_airspeed(void);

/*  SerialCom.pde  */
void readSerialCommand();
void sendSerialTelemetry();
float readFloatSerial();

#include "ArduCopter_SuperStable.pde"

#include "ArduCopter_SuperStable/DCM.pde"
#include "ArduCopter_SuperStable/Functions.pde"
#include "ArduCopter_SuperStable/Log.pde"
#include "ArduCopter_SuperStable/Navigation.pde"
#include "ArduCopter_SuperStable/Sensors.pde"
#include "ArduCopter_SuperStable/SerialCom.pde"


//Fix linker error
extern "C" void __cxa_pure_virtual() { cli(); while (1); }




